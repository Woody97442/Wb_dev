<?php
require_once __DIR__. '../vendor/autoload.php' ;

use Gregwar\Captcha\CaptchaBuilder;
use Gregwar\Captcha\PhraseBuilder;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './vendor/phpmailer/PHPMailer/src/Exception.php';
require './vendor/phpmailer//PHPMailer/src/PHPMailer.php';
require './vendor/phpmailer//PHPMailer/src/SMTP.php';

// We need the session to check the phrase after submitting
session_start();
$captcha = new CaptchaBuilder();
// Running the actual rendering of the captcha image
$captcha ->build();

$messageCaptcha = "";
$sendMessage = "";


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  // Checking that the posted phrase match the phrase stored in the session
  if (isset($_SESSION['phrase']) && PhraseBuilder::comparePhrases($_SESSION['phrase'], $_POST['phrase'])) {
    
    if(isset($_POST['nom'])){

      //Create an instance; passing `true` enables exceptions
      $mail = new PHPMailer(true);

      try {
          //Server settings
          $mail->setLanguage('fr', '/optional/path/to/language/directory/');
          $mail->isSMTP();                                            //Send using SMTP
          $mail->Host       = 'smtp-mail.outlook.com';                     //Set the SMTP server to send through
          $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
          $mail->Username   = 'woody_test_smtp@outlook.fr';                     //SMTP username
          $mail->Password   = 'Woody97442';                               //SMTP password
          $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
          $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

          // L'expéditeur
          $mail->setFrom('woody_test_smtp@outlook.fr');
          // Destinataires
          $mail->addAddress('woody_test_smtp@outlook.fr');

          //Content
          $mail->Subject = 'Envoyer par : ' . $_POST['email'];
          $mail->Body    = $_POST['message'];
          $mail->AltBody = $_POST['nom'];

          $mail->send();
          $sendMessage = '<div class="alert alert-success p-1 text-center col-sm-6" role="alert">Message bien envoyer</div';
      } catch (Exception $e) {
          $sendMessage = '<div class="alert alert-danger p-1 text-center col-sm-6" role="alert">Message non envoyer !</div';
      }
    }
    
    $messageCaptcha = '<div class="alert alert-success p-1 text-center col-sm-6" role="alert">Captcha is valid !</div>';
  
  } else {
    $messageCaptcha = '<div class="alert alert-danger p-1 text-center col-sm-6" role="alert">Captcha is not valid !</div>';
  }
  // The phrase can't be used twice
  unset($_SESSION['phrase']);
}

$_SESSION['phrase'] = $captcha->getPhrase();

?>

<!doctype html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="formulaire de contact">
  <title>formulaire de contact</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.7.3/themes/base/jquery-ui.css">
</head>

<body class="d-flex  vh-100 align-items-center bg-secondary">

  <div class="container align-items-center">
    <h1 class="text-white">Formulaires</h1>

    <form class="text-white" method="post">

      
      <div class="form-group">
        <div class="col-sm-6 mt-2">
          <?= (isset($sendMessage)) ? $sendMessage : ""; ?>
          <label for="nom">Entrez votre nom</label>
          <input type="text" class="form-control" name="nom" value="<?= (isset($_POST['nom'])) ? $_POST['nom'] : ""; ?>">
        </div>
      </div>
      
      <div class="form-group">
        <div class="col-sm-6 mt-2">
          <label for="email">Entrez votre mail</label>
          <input type="email" class="form-control" name="email" value="<?= (isset($_POST['email'])) ? $_POST['email'] : ""; ?>">
        </div>
      </div>
      
      <div class="form-group">
        <div class="col-sm-6 mt-2">
          <label for="message">Message</label>
          <textarea class="form-control" name="message" rows="3"><?= (isset($_POST['message'])) ? $_POST['message'] : ""; ?></textarea>
        </div>
      </div>

      <div class="form-group my-2">
        
        <?= (isset($messageCaptcha)) ? $messageCaptcha : ""; ?>
        <img src="<?php echo $captcha->inline(); ?>"/><br/>
        Phrase: <?php echo $captcha->getPhrase(); ?>

        <div class="col-sm-6 mt-2">
          <label for="captcha">Entrez le code</label>
          <input type="text" class="form-control" name="phrase">
        </div>

      </div>

      <div class="form-group row">
        <div class="col-sm-6 mt-2">
          <button type="submit" class="btn btn-primary">Envoyer</button>
        </div>
      </div>

    </form>

</div>


  <!-- Les script et import JavaScript -->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


</body>

</html>