<div class="container">
    <div class="row">
        <div class="col-12 d-flex flex-column justify-content-center align-items-center">
            <h1 class="text-center text-white ">Page Register</h1>
            <div class="my-4">
                <a class="btn btn-success mx-2" href="./home">Home</a>
                <a class="btn btn-success mx-2" href="./login">Login</a>
                <a class="btn btn-success mx-2" href="./register">Register</a>
                <a class="btn btn-success mx-2" href="./dashbord">Dashbord</a>
            </div>
        </div>
    </div>
</div>