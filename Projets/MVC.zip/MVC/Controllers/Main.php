<?php

class Main extends Controller{

    public function index(){
        $this->render('index');
    }

}