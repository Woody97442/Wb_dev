<?php

class Dashbord extends Controller{

    public function index(){
        $this->render('index');
    }

}