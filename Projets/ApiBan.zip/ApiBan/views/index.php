<?php


?>

<!doctype html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Utilisation de L'API BAN">
  <title>Utilisation de L'API BAN</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.7.3/themes/base/jquery-ui.css">
</head>

<body class="d-flex  vh-100 align-items-center bg-secondary">

  <div class="container">
      <div class="row">
          <div class="col-12 ">
            <form action="" method="post" class="d-flex flex-column card shadow p-2">
              <h3 class="text-center">Recherche d'adresse</h3>
              <input name="adresse" id="adresse" type="text" placeholder="Adresse" class="my-1">
              <input name="cp" id="cp" type="text" placeholder="CP" class="my-1">
              <input name="ville" id="ville" type="text" placeholder="Ville" class="my-1">
            </form>
          </div>
      </div>
  </div>


  <!-- Les script et import JavaScript -->

  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


  <script>
    $("#adresse").autocomplete({
      source: function(request, response) {
        $.ajax({
          url: "https://api-adresse.data.gouv.fr/search/?postcode=" + $("input[name='cp']").val(),
          data: {
            q: request.term
          },
          dataType: "json",
          success: function(data) {
            var name = [];
            response($.map(data.features, function(item) {

              if ($.inArray(item.properties.name, name) == -1) {
                  name.push(item.properties.name);
                  return {
                    label: item.properties.name + " - " + item.properties.postcode + " - " + item.properties.city,
                    value: item.properties.name,
                    postcode: item.properties.postcode,
                    city: item.properties.city,
                  };
                }
            }));
          }
        });
      },
      // On remplit aussi la ville
      select: function(event, ui) {
        $('#ville').val(ui.item.city);
        $('#cp').val(ui.item.postcode);
      }

    });

  </script>

  <script>

    $("#cp").autocomplete({
      source: function(request, response) {
        $.ajax({
          url: "https://api-adresse.data.gouv.fr/search/?postcode=" + $("input[name='cp']").val(),
          data: {
            q: request.term
          },
          dataType: "json",
          success: function(data) {
            var postcodes = [];
            response($.map(data.features, function(item) {
              // Ici on est obligé d'ajouter les CP dans un array pour ne pas avoir plusieurs fois le même
              if ($.inArray(item.properties.postcode, postcodes) == -1) {
                postcodes.push(item.properties.postcode);
                return {
                  label: item.properties.postcode + " - " + item.properties.city,
                  city: item.properties.city,
                  value: item.properties.postcode
                };
              }
            }));
          }
        });
      },

      // On remplit aussi la ville
      select: function(event, ui) {
        $('#ville').val(ui.item.city);
      }
    });

  </script>

  <script>
    $("#ville").autocomplete({
      source: function(request, response) {
        $.ajax({
          url: "https://api-adresse.data.gouv.fr/search/?city=" + $("input[name='ville']").val(),
          data: {
            q: request.term
          },
          dataType: "json",
          success: function(data) {
            var cities = [];
            response($.map(data.features, function(item) {
              // Ici on est obligé d'ajouter les villes dans un array pour ne pas avoir plusieurs fois la même
              if ($.inArray(item.properties.postcode, cities) == -1) {
                cities.push(item.properties.postcode);
                return {
                  label: item.properties.postcode + " - " + item.properties.city,
                  postcode: item.properties.postcode,
                  value: item.properties.city
                };
              }
            }));
          }
        });
      },

      // On remplit aussi le CP
      select: function(event, ui) {
        $('#cp').val(ui.item.postcode);
      }
    });

  </script>




</body>

</html>